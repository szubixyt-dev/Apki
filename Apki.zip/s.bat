@echo off
chcp 65001 >nul
echo Ładowanie...
title Apki Build 2.1
setlocal EnableDelayedExpansion
if not exist "%SETTINGS%\color.cfg" echo 1F>"%SETTINGS%\color.cfg"
set /p COLORCFG=<"%SETTINGS%\color.cfg"
color %COLORCFG%
set "APPDIR=%APPDATA%\Bridge Studios\Apki"
set "PACKAGES=%APPDIR%\packages"
set "SETTINGS=%APPDIR%\settings"
if not exist "%APPDIR%" mkdir "%APPDIR%"
if not exist "%PACKAGES%" mkdir "%PACKAGES%"
if not exist "%SETTINGS%" mkdir "%SETTINGS%"

echo Wyszukiwanie potencjalnych aktualizacji...
set "wersja=5"

if not exist "%APPDIR%\settings\noupdates" (

    powershell -NoProfile -Command "Invoke-WebRequest 'https://raw.githubusercontent.com/szubixyt-dev/Apki/main/version.txt' -UseBasicParsing -OutFile '%TEMP%\version.txt'"

    set /p onlinever=<"%TEMP%\version.txt"

    echo Online: [!onlinever!]
    echo Lokalna: [!wersja!]

    if not "!onlinever!"=="!wersja!" (
        msg * Znaleziono aktualizacje! Aktualizowanie programu...
		copy "%APPDIR%\uninstaller\updater.bat" "%TEMP%"
        start "" "%TEMP%\updater.bat"
        exit
    )
)

:menu
color %COLORCFG%
cls
echo.
echo ==================================================
echo                     APKI
echo                    BUILD 2.1
echo ==================================================
echo.
echo  1. Pakiety
echo  2. Ustawienia
echo  3. Informacje
echo  4. Instrukcja
echo  5. Instalator
echo  6. Odinstalator
echo  7. Wyjście
echo.	
set /p wybor="Wybierz opcje: " 

if "%wybor%"=="1" goto packages
if "%wybor%"=="2" goto settings
if "%wybor%"=="3" goto info
if "%wybor%"=="4" goto instrukcja
if "%wybor%"=="5" goto install
if "%wybor%"=="6" goto uninstall
if "%wybor%"=="7" exit

goto menu

:install
color %COLORCFG%
cls
title Instalator Programow

echo ==========================================
echo               INSTALATOR
echo ==========================================
echo.
echo Przyklady:
echo Google.Chrome
echo (firma).(program)
echo.
echo Wpisz program do instalacji.
echo Wpisz 0 aby wrocic.
echo.

set /p "input=> "

if "%input%"=="0" goto menu

winget install "%input%"

echo.
echo Kliknij dowolny przycisk by kontynuować
pause >nul
goto install

:packages
cls
echo ==========================================
echo                 PAKIETY
echo ==========================================
echo.

echo Wkrótce!
echo.
echo Kliknij dowolny przycisk by kontynuować
pause >nul
goto menu

:settings
cls
echo ==========================================
echo               USTAWIENIA
echo ==========================================
echo.
echo Wybierz kolor tla:
echo.
echo 0. Bialy
echo 1. Czarny
echo 2. Niebieski
echo 3. Zielony
echo 4. Aqua
echo 5. Czerwony
echo 6. Fioletowy
echo 7. Zolty
echo 8. Szary
echo 9. Jasno niebieski
echo 10. Jasno zielony
echo 11. Jasny Aqua
echo 12. Jasno czerwony
echo 13. Jasno fioletowy
echo 14. Bezowy
echo.

set /p input=Wybierz: 

if "%input%"=="0" set NEWCOLOR=F0
if "%input%"=="1" set NEWCOLOR=0F
if "%input%"=="2" set NEWCOLOR=1F
if "%input%"=="3" set NEWCOLOR=2F
if "%input%"=="4" set NEWCOLOR=3F
if "%input%"=="5" set NEWCOLOR=4F
if "%input%"=="6" set NEWCOLOR=5F
if "%input%"=="7" set NEWCOLOR=6F
if "%input%"=="8" set NEWCOLOR=8F
if "%input%"=="9" set NEWCOLOR=9F
if "%input%"=="10" set NEWCOLOR=AF
if "%input%"=="11" set NEWCOLOR=B0
if "%input%"=="12" set NEWCOLOR=CF
if "%input%"=="13" set NEWCOLOR=DF
if "%input%"=="14" set NEWCOLOR=E0

if not defined NEWCOLOR goto m

echo %NEWCOLOR%>"%SETTINGS%\color.cfg"

set /p COLORCFG=<"%SETTINGS%\color.cfg"
color %COLORCFG%

goto menu

:info
cls
echo ==========================================
echo               INFORMACJE
echo ==========================================
echo.
echo Nazwa: Apki
echo Wersja: Reprogram Build 2.1
echo.
echo Folder programu:
echo %APPDIR%
echo.
echo 294 Linijek programu
echo.
echo Kliknij dowolny przycisk by kontynuować
pause >nul
goto menu

:instrukcja
cls
echo ==========================================
echo            INSTRUKCJA OBSŁUGI
echo ==========================================
echo.
echo 1. Masz do wyboru kilkanaście obcji
echo.
echo 2. Odinstalowanie
echo - Odinstaluj programy na swoim komputerze
echo .
echo 3. Instalowanie
echo - Zainstaluj programy wpisując ich Package ID (można spróbować (firma).(program))
echo.
echo 4. Pakiety
echo - Pakiety są po to by rzeczy ktorych nie da sie zainstalować przez obecny instalator
echo będzie można ale tylko po zainstalowaniu pakietów
echo.
echo Kliknij dowolny przycisk by kontynuować
pause >nul
goto menu

:uninstall
color %COLORCFG%
cls
title Odinstalator Programow

echo ==========================================
echo              ODINSTALATOR
echo ==========================================
echo.
echo Ładowanie...
winget list
echo.
echo Wpisz nazwę programu do usunięcia, np. Apki
echo Wpisz 0 aby wrócić do menu.
echo.
set /p "input=> "

if "%input%"=="Apki" goto odinstalujprogram
if "%input%"=="0" goto menu

winget uninstall "%input%"

echo.
echo Kliknij dowolny przycisk by kontynuować
pause >nul
goto uninstall

:odinstalujprogram
echo ==========================================
echo              ODINSTALATOR
echo ==========================================
echo.
choice /M "Czy jestes pewny?"

if errorlevel 2 goto menu
if errorlevel 1 goto protokolodinstalowania

:protokolodinstalowania
cls
echo Przygotowywanie zasobów
rmdir /s /q "%TEMP%\uninstall"
mkdir "%TEMP%\uninstall"
copy "C:\Users\%username%\AppData\Roaming\Bridge Studios\Apki\uninstaller\uninstall.bat" "%TEMP%\uninstall"
echo.
echo Startowanie odinstalatora
start "" "%TEMP%\uninstall\uninstall.bat"
exit