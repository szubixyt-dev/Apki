@echo off
chcp 65001 >nul
set "APPDIR=%APPDATA%\Bridge Studios"
echo Usuwanie...
rmdir /s /q "%APPDIR%"
rmdir /q "%APPDIR%\Apki"
rmdir /q "%APPDIR%"
cls
echo Usuwanie...
echo Usunięto program
echo.
echo Kliknij dowolny przycisk by zamknąć program
pause >nul