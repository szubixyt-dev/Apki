@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
set "APPDIR=%APPDATA%\Bridge Studios"
timeout 1 >nul
call :center "Usuwanie..."
rmdir /s /q "%APPDIR%"
rmdir /q "%APPDIR%\Apki"
rmdir /q "%APPDIR%"
powershell -Command "Start-Process cmd -Verb runAs -ArgumentList '/c del /f /q \"C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Apki.lnk\"'"
del /q "C:\Users\%username%\Desktop\Apki.lnk"
cls
call :center "Usuwanie..."
call :center "Usunięto program"
echo.
call :center "Kliknij dowolny przycisk by zamknąć program"
pause >nul
exit

:center
set "text=%~1"

:: długość tekstu
set "tmp=%text%"
set /a len=0

:lenloop
if defined tmp (
    set "tmp=!tmp:~1!"
    set /a len+=1
    goto lenloop
)

:: szerokość okna
for /f "tokens=2 delims=:" %%a in ('mode con ^| findstr Columns') do set cols=%%a
set cols=%cols: =%

set /a pad=(cols-len)/2

set "spaces="
for /l %%i in (1,1,%pad%) do set "spaces=!spaces! "

echo(!spaces!!text!
goto :eof