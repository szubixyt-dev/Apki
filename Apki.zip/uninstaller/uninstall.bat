@echo off
chcp 65001 >nul
set "APPDIR=%APPDATA%\Bridge Studios"
timeout 3 >nul
echo Usuwanie...
rmdir /s /q "%APPDIR%"
rmdir /q "%APPDIR%\Apki"
rmdir /q "%APPDIR%"
powershell -Command "Start-Process cmd -Verb runAs -ArgumentList '/c del /f /q \"C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Apki.lnk\"'"
del /q "C:\Users\%username%\Desktop\Apki.lnk"
cls
echo Usuwanie...
echo Usunięto program
echo.
echo Kliknij dowolny przycisk by zamknąć program
pause >nul