@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
set "APPDIR=%APPDATA%\Bridge Studios"
timeout 1 >nul
call :center "Aktualizowanie..."
powershell -Command "Start-Process cmd -Verb runAs -ArgumentList '/c del /f /q \"C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Apki.lnk\"'"
del /q "C:\Users\%username%\Desktop\Apki.lnk"
cls
call :center "Aktualizowanie..."
call :center "Tworzenie folderów..."

mkdir "%APPDIR%"
mkdir "%APPDIR%\Apki" 2>nul
call :center "Pobieranie plików..."

:: pobieranie
powershell -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/szubixyt-dev/Apki/main/Apki.zip' -OutFile '%TEMP%\apki.zip'"

call :center "Wypakowywanie..."

powershell -Command "Expand-Archive -Path '%TEMP%\apki.zip' -DestinationPath '%APPDIR%\Apki' -Force"

call :center "Instalacja zakończona."
powershell -Command ^
"$s=(New-Object -COM WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\Apki.lnk'); ^
$s.TargetPath='%APPDATA%\Bridge Studios\Apki\s.bat'; ^
$s.IconLocation='%APPDATA%\Bridge Studios\Apki\i.ico'; ^
$s.Save()"
powershell -Command "Start-Process cmd -Verb runAs -ArgumentList '/c powershell -NoProfile -Command \"$s=New-Object -COM WScript.Shell; $l=$s.CreateShortcut(''C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Apki.lnk''); $l.TargetPath=$env:APPDATA + ''\Bridge Studios\Apki\s.bat''; $l.IconLocation=$env:APPDATA + ''\Bridge Studios\Apki\i.ico''; $l.Save()\"'"
call :center "Skróty utworzone"
del /q "%TEMP%\apki.zip"
echo.
call :center "Kliknij dowolny przycisk aby wyjść"
pause >nul
exit

:center
set "text=%~1"

:: długość tekstu
set "tmp=%text%"
set /a len=0

:lenloop
if defined tmp (
    set "tmp=!tmp:~1!"
    set /a len+=1
    goto lenloop
)

:: szerokość okna
for /f "tokens=2 delims=:" %%a in ('mode con ^| findstr Columns') do set cols=%%a
set cols=%cols: =%

set /a pad=(cols-len)/2

set "spaces="
for /l %%i in (1,1,%pad%) do set "spaces=!spaces! "

echo(!spaces!!text!
goto :eof