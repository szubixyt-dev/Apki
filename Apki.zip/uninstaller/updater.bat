@echo off
chcp 65001 >nul
set "APPDIR=%APPDATA%\Bridge Studios"
timeout 3 >nul
echo Aktualizowanie...
rmdir /s /q "%APPDIR%"
rmdir /q "%APPDIR%\Apki"
rmdir /q "%APPDIR%"
powershell -Command "Start-Process cmd -Verb runAs -ArgumentList '/c del /f /q \"C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Apki.lnk\"'"
del /q "C:\Users\%username%\Desktop\Apki.lnk"
cls
echo Aktualizowanie...
echo Tworzenie folderów...

mkdir "%APPDIR%"
mkdir "%APPDIR%\Apki" 2>nul
echo Pobieranie plików...

:: pobieranie
powershell -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/szubixyt-dev/Apki/main/Apki.zip' -OutFile '%TEMP%\apki.zip'"

echo Wypakowywanie...

powershell -Command "Expand-Archive -Path '%TEMP%\apki.zip' -DestinationPath '%APPDIR%\Apki' -Force"

echo Instalacja zakończona.
powershell -Command ^
"$s=(New-Object -COM WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\Apki.lnk'); ^
$s.TargetPath='%APPDATA%\Bridge Studios\Apki\s.bat'; ^
$s.IconLocation='%APPDATA%\Bridge Studios\Apki\i.ico'; ^
$s.Save()"
powershell -Command "Start-Process cmd -Verb runAs -ArgumentList '/c powershell -NoProfile -Command \"$s=New-Object -COM WScript.Shell; $l=$s.CreateShortcut(''C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Apki.lnk''); $l.TargetPath=$env:APPDATA + ''\Bridge Studios\Apki\s.bat''; $l.IconLocation=$env:APPDATA + ''\Bridge Studios\Apki\i.ico''; $l.Save()\"'"
echo Skróty utworzone
del /q "%TEMP%\apki.zip"
echo.
echo Kliknij dowolny przycisk aby wyjść
pause >nul
exit